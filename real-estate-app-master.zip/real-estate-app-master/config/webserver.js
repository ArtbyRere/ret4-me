module.exports = {
	hostname: 'localhost',
	http: {
		port: 3000,
		proxyPort: 3000
	}//,
	// https: {
	// 	port: 434,
	//	proxyPort: 3434
	// 	keyPath: 'insecure.key',
	// 	certPath: 'insecure.crt'
	// }
};